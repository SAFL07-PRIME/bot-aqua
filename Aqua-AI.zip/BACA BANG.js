KODE PAIRING : SATAGANZ

BOT HANYA BISA DI GROUP DAN GAK BISA DI MODE PRIVATE

CARA NYA 
.addgb 
bot otomatis save id group tersebut, hanya group tertentu yang bisa menggunakan bot
jika kamu sudah .addgb ke group maka bot bisa digunakan 

jika ingin hapus group tersebut 
.delgb 
bot otomatis hapus id grup tersebut dan bot tidak bisa digunakan kecuali kamu add kembali

apabila apikey habis silahkan register ke website kami

https://free-restapi.biz.id/

Owner ada di database/owner.json
premium ada di database/premium.json