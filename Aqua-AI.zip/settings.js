require("./satanic")
const fs = require('fs')

global.owner = "6285707390310",
global.nobot = "6283168758640"
global.namaowner = "Lynzz Official"
global.namaBot = "Aqua-AI MD"
global.title = "satan"
global.domain = "https://newcodingproject.vercel.app/"
global.thumbnail = "https://c.termai.cc/i108/58xw.jpg" //// ganti thumbnail sesuaikan kalian
// Jangan Di ubah
global.creator = `${owner}@s.whatsapp.net` 
global.foother = `© ${namaBot}`
global.versi = "New"
global.pairing = "SATAGANZ" //PAIRING TIDAK BISA DI UBAH////
//////NOTE TIDAK BERUBAH KODE PAIRING YANG ADA EROR///////////
global.idch = "120363405828268965@newsletter"
global.linkSaluran = "https://whatsapp.com/channel/0029VbC0gHGLdQefKKdfJP3S"
global.onlygrup = true
global.sakey = "SK-F1C7505861022B7D61FF6DB0" //jika apikey habis silahkan register 
//// https://free-restapi.biz.id// ///
///ambil apikey di website itu//////

global.fgsi = "isi apikey nya di website di bawah ini"
///// https://fgsi.dpdns.org //// Ambil Apikey di situ///))/
global.neoxr = "isi apikey nya di website di bawah ini"
/// https://api.neoxr.eu/ /////Ambil apikey di website itu////
global.allowedGroupIds = global.allowedGroupIds || [""];


global.banned = []
global.nama = namaBot 
global.namach = nama 
global.namafile = foother 
global.author = namaowner
global.welcome = false
global.leave = false
global.antitags = false
global.welcomeMsg = "awkawkwwk"
global.leaveMsg = "awkww yatim oit"
global.autoreadsw = false
global.autoreactsw = false
global.autoreactemoji = '😂'

global.prefix = ".", "/", "#"


// Settings reply ~~~~~~~~~//
global.mess = {
    owner: "Khusus Owner",
    prem: "Khusus Premium",
    group: "Khusus di Group Chat",
    admin: "Khusus Admin",
    botadmin: "Bot Harus Jadi Admin",
    private: "Khusus di Private Chat",
    done: "Sukses"
}

global.packname = nama
global.author = namaBot

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})